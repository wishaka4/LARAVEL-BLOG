<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/#">Blogger</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/blog">Recently added</a></li>
      <li><a href="/contact">Contact</a></li>
      <li><a href="/about">About Us</a></li>
      <li><a href="#">Portfolio</a></li>
    </ul>
  </div>
  </nav>