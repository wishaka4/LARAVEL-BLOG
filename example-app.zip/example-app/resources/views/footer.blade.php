<!-- Footer -->
<footer class="container-fluid bg-4 text-center" style="background-color: #bbb;
  margin: 0 auto;
  padding: 29px;">
  <p>Bootstrap Theme Made By <a href="https://www.w3schools.com">www.w3schools.com</a></p> 
</footer>